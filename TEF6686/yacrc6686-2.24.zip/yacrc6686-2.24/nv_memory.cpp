#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include "global.h"
#include "nv_memory.h"
#include "ui.h"

extern uint8_t nRFMode;         // FM/AM
extern uint8_t nVolume;         // Audio volume control, 0-29
extern uint8_t nBacklightAdj;   // LCD backlight value, 0-255
extern uint8_t nBacklightKeep;  // LCD backlight auto keep seconds, 0-255, 0 for always on
extern uint8_t nFMCEQ;          // FM channel equalizer, 0=off, 1=on
extern uint8_t nFMEMS;          // FM enhanced multipath suppression, 0=off, 1=on
extern uint8_t nDeemphasis;     // FM de-emphasis, 0=off, 1=50us, 2=75us
extern uint8_t nBand;           // Band: LW/MW/SW/FM
extern const int32_t nBandFMin[NUM_BANDS];
extern const int32_t nBandFMax[NUM_BANDS];
extern int32_t nBandFreq[NUM_BANDS];        // Band default frequency
extern uint8_t nStepIdx;   // Step index for current band
extern uint8_t nFMFilter;  // Current FIR filter index for FM
extern uint8_t nAMFilter;  // Current FIR filter index for AM

void NVMInit(void)
{
#if DEBUG
	Serial.println(F("NVMInit"));
#endif
	LCDXYStr_P(0, 1, (PGM_P)F("Init NV Mem? "));
	if (YesNo(false))
	{
		LCDXYStr_P(0, 1, (PGM_P)F("Initializing ..."));
		NVMUnpkWrData(NVM_INIT, NVMADDR_SIG);  // Initialize NV memory
	}
}

void NVMGetArgs(void)
{
	uint8_t u8, i;
	uint16_t u16;

	if (eeprom_read_dword((uint32_t *)NVMADDR_SIG) != (NVMSIG))
		NVMInit();

	nBand = NV_read_byte((uint8_t *)NVMADDR_BAND);
	if (nBand >= NUM_BANDS)
		nBand = BAND_FM;

	nVolume = NV_read_byte((uint8_t *)NVMADDR_VOL);
	if (nVolume > MAX_VOL)
		nVolume = 10;

	nRFMode = NV_read_byte((uint8_t *)NVMADDR_RFMODE);
	if (nRFMode >= NUM_RFMODES)
		nRFMode = RFMODE_FM;

	nStepIdx = NV_read_byte((uint8_t *)NVMADDR_STEPIDX);
	if (nStepIdx >= NUM_STEPS)
		nStepIdx = 0;

	nFMFilter = NV_read_byte((uint8_t *)NVMADDR_FMFILTER);
	if (nFMFilter > NUM_FM_FILTERS)
		nFMFilter = DEF_FM_FILTER;

	nAMFilter = NV_read_byte((uint8_t *)NVMADDR_AMFILTER);
	if (nAMFilter > NUM_AM_FILTERS)
		nAMFilter = DEF_AM_FILTER;

	u8 = NV_read_byte((uint8_t *)NVMADDR_MISC1);
	nDeemphasis = u8 >> 6;            // FM de-emphasis, 0=off, 1=50us, 2=75us
	if (nDeemphasis > 2)
		nDeemphasis = DEEMPH50;

	u8 = NV_read_byte((uint8_t *)NVMADDR_MISC2);
	nFMEMS = u8 >> 7;                 // FM enhanced multipath suppression, 0=off, 1=on
	nFMCEQ = (u8 >> 5) & 1;           // FM channel equalizer, 0=off, 1=on

	nBacklightAdj = NV_read_byte((uint8_t *)NVMADDR_BKADJ);
	nBacklightKeep = NV_read_byte((uint8_t *)NVMADDR_BKKEEP);

	for (i = 0; i < NUM_BANDS; i++)
	{
		u16 = NV_read_word((uint16_t *)NVMADDR_BANDFREQ + i);
		if (u16 == 0xffff)  // Blank ch
			nBandFreq[i] = nBandFMin[i];
		else if (i <= BAND_SW)
			nBandFreq[i] = nBandFMin[i] + u16;
		else
			nBandFreq[i] = nBandFMin[i] + (int32_t)u16 * 5;
		nBandFreq[i] = constrain(nBandFreq[i], nBandFMin[i], nBandFMax[i]);
	}
}  // void NVMGetArgs(void)

void NVMUnpkWrData(const uint8_t* pPGMAddr, uint8_t *pNVMAddr)
{
	uint8_t *pF = (uint8_t *)pPGMAddr;
	uint8_t *pNVM = pNVMAddr;
	uint8_t len, i, val;
	for (;;)
	{
		len = pgm_read_byte_near(pF++);
		if (!len)
			break;
		if (len & 0x80)
		{  // Dup
			val = pgm_read_byte_near(pF++);
			for (i = 0; i < (len & 0x7f); i++)
				NV_write_byte(pNVM++, val);
		}
		else
		{  // len bytes data
			for (i = 0; i < len; i++)
				NV_write_byte(pNVM++, pgm_read_byte_near(pF++));
		}
	}
}

#if DEBUG
uint8_t NV_read_byte(uint8_t *p)
{
	uint8_t val;

	val = eeprom_read_byte(p);
	Serial.print(F("NVRd8 a="));
	Serial.print((uint16_t)p);
	Serial.print(F(" d="));
	Serial.println(val);
	return val;
}


uint16_t NV_read_word(uint16_t *p)
{
	uint16_t val;

	val = eeprom_read_word(p);
	Serial.print(F("NVRd16 a="));
	Serial.print((uint16_t)p);
	Serial.print(F(" d="));
	Serial.println(val);
	return val;
}


void NV_write_byte(uint8_t *p, uint8_t val)
{
	Serial.print(F("NVWr8 a="));
	Serial.print((uint16_t)p);
	Serial.print(F(" d="));
	Serial.println(val);
	eeprom_write_byte(p, val);
}


void NV_write_word(uint16_t *p, uint16_t val)
{
	Serial.print(F("NVWr16 a="));
	Serial.print((uint16_t)p);
	Serial.print(F(" d="));
	Serial.println(val);
	eeprom_write_word(p, val);
}
#endif