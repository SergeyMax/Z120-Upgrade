#include "global.h"
void Set_Cmd(uint8_t mdl, uint8_t cmd, int len, ...);
void Get_Cmd(uint8_t mdl, uint8_t cmd, uint16_t *receive, uint8_t len);
void dsp_write_data(const uint8_t*);
void SetVolume(uint8_t);
void CheckVolume(void);
void NextFilter(void);
void SetFilter(bool bNeedSync);
void SetRFCtrlReg(void);
void TuneFreq(int32_t);
void AdjFreq(bool bCurrStep = true);
void TuneFreqDisp(void);
void ProcBand(uint8_t nBd);
void ProcStepFilter(uint8_t nKey);
void GetRFStatReg(void);
void SetRFMode(void);
void AddSyncBits(uint16_t SyncBit);