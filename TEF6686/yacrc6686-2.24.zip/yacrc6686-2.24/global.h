#include <Arduino.h>

#ifndef PGM
#define PGM     __attribute__((section(".progmem.data")))
#endif

//#define DEBUG           1

#define DSP_I2C      0xC8

// Pins
#define SCL_PIN        A5
#define SDA_PIN        A4

#define SH1A_PIN        2
#define SH1B_PIN        7
#define SH2A_PIN        3
#define SH2B_PIN       A1
#define KS1_PIN        A0

#define LCD_RS_PIN      4
#define LCD_E_PIN      12
#define LCD_BKLT_PIN    6

#define LED_PIN        13

// RF Modes
#define NUM_RFMODES     2
#define RFMODE_FM       0
#define RFMODE_AM       1

// Volume
#define MIN_VOL         0
#define MAX_VOL        29

// Bands
#define NUM_BANDS       4
#define BAND_LW         0
#define BAND_MW         1
#define BAND_SW         2
#define BAND_FM         3

// Steps
#define NUM_STEPS       3  // Step values for each band

// Deemphasis
#define DEEMPHOFF       0
#define DEEMPH50        1
#define DEEMPH75        2

// Filters
#define NUM_FM_FILTERS  17  // Auto + 16 fixed bandwidth filters
#define NUM_AM_FILTERS   4  // 4 fixed bandwidth filters
#define DEF_FM_FILTER    0
#define DEF_AM_FILTER    1

// Need auto sync to NV memory, bits definition
#define NEEDSYNC_BAND       0x0001
#define NEEDSYNC_VOL        0x0002
#define NEEDSYNC_RFMODE     0x0008
#define NEEDSYNC_STEPIDX    0x0020
#define NEEDSYNC_FMFILTER   0x0040
#define NEEDSYNC_AMFILTER   0x0080
#define NEEDSYNC_MISC1      0x0100
#define NEEDSYNC_MISC2      0x0200
#define NEEDSYNC_MISC3      0x0400

#define TIMER_INTERVAL      1000   // Check signal level, RSSI��SNR and FM stereo indicator every TIMER_INTERVAL, ms
#define TIMER_ALTDISP       3000   // Must be bigger than TIMER_INTERVAL, ms
#define TIMER_AUTOSYNC      5000   // Must be bigger than TIMER_INTERVAL, ms