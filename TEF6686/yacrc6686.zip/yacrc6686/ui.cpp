#include <avr/eeprom.h>
#include <avr/sleep.h>
#include "I2cMaster.h"
#include "global.h"
#include "yacrc6686.h"
#include "init6686.h"
#include "ui.h"
#include "nv_memory.h"

extern uint8_t nFMCEQ;         // FM channel equalizer, 0=off, 1=on
extern uint8_t nFMEMS;         // FM enhanced multipath suppression, 0=off, 1=on
extern uint8_t nDeemphasis;    // FM de-emphasis, 0=off, 1=50us, 2=75us

extern int8_t nRSSI, nRSSI_Last, nRSSI_Disp;  // Received signal strength, in dBuv
extern int8_t nSNR, nSNR_Last, nSNR_Disp;     // Signal noise ratio, in dB
extern bool bSTIN;                            // FM stereo indicator

extern uint8_t nVolume;      // Audio volume control, 0-29
extern uint8_t nRFMode;      // FM/AM

extern uint8_t nBand;        // Band: LW/MW/SW/FM
extern const int32_t nBandFMin[NUM_BANDS];
extern const int32_t nBandFMax[NUM_BANDS];
extern const int16_t nBandStep[NUM_BANDS][NUM_STEPS];
extern int32_t nBandFreq[NUM_BANDS];       // Band default frequency

extern uint8_t nStepIdx;    // Step index for current band
extern uint8_t nFMFilter;   // Current FIR filter index for FM
extern uint8_t nAMFilter;   // Current FIR filter index for AM
extern uint16_t M_FMFilter[];
extern uint8_t M_AMFilter[];

extern uint8_t nBacklightAdj;     // LCD backlight value, 0-255
extern uint8_t nBacklightKeep;    // LCD backlight auto keep seconds, 0-255, 0 for always on
extern bool bLCDOff;              // true for LCD is off
extern uint32_t nBacklightTimer;  // LCD backlight auto keep timer in ms

extern uint8_t nDelayedSmooth;

volatile int8_t nLRot;
volatile int8_t nRRot;

extern TwiMaster i2c;

const char *pszBands[] = { "LW", "MW", "SW", "FM" };  // Band name to display
bool bExitMenu;

// Special menu strings
const char MT_RET[] PGM = "RET";
const char MT_EXIT[] PGM = "EXIT";

// Menu Option(Left encoder)
const char MT_FMCE[] PGM = "FMCE";  // FM channel equalizer
const char MT_FMMP[] PGM = "FMMP";  // FM enhanced multipath suppression
const char MT_DEEM[] PGM = "DEEM";  // FM de-emphasis
const char MT_BKLT[] PGM = "BKLT";

M_ITEM M_Option[] =
{
    {MID_FMCE, MT_FMCE},
    {MID_FMMP, MT_FMMP},
    {MID_DEEM, MT_DEEM},
    {MID_BKLT, MT_BKLT},
    {MID_EXIT, MT_EXIT}
};

// Menu Option->FMCE
const char MT_FMCEOFF[] PGM = "OFF";
const char MT_FMCEON[] PGM = "ON";

M_ITEM M_FMCE[] =
{
    {MID_FMCEOFF, MT_FMCEOFF},
    {MID_FMCEON, MT_FMCEON}
};

// Menu Option->FMMP
const char MT_FMMPOFF[] PGM = "OFF";
const char MT_FMMPON[] PGM = "ON";

M_ITEM M_FMMP[] =
{
    {MID_FMMPOFF, MT_FMMPOFF},
    {MID_FMMPON, MT_FMMPON}
};


// Menu Option->DEEM
const char MT_DEEM0[] PGM = "OFF";
const char MT_DEEM50[] PGM = "50US";
const char MT_DEEM75[] PGM = "75US";

M_ITEM M_DEEM[] =
{
    {MID_DEEM0, MT_DEEM0},
    {MID_DEEM50, MT_DEEM50},
    {MID_DEEM75, MT_DEEM75}
};

// Menu Option->BKLT
const char MT_BKKEEP[] PGM = "KEEP";
const char MT_BKADJ[] PGM = "ADJ";

M_ITEM M_BkLt[] =
{
    {MID_BKKEEP, MT_BKKEEP},
    {MID_BKADJ, MT_BKADJ},
    {MID_RET, MT_RET}
};


// Menu Frequency(Right encoder)
const char MT_STAT[] PGM = "STAT";
const char MT_SLP[]  PGM = "SLP";

M_ITEM M_Frequency[] =
{
    {MID_SLP,  MT_SLP},
    {MID_STAT, MT_STAT},
    {MID_EXIT, MT_EXIT}
};

M_SUBMENU SM_List[] =
{
    {MID_OPTION, M_Option, sizeof(M_Option) / sizeof(M_ITEM)},           // Menu Option
    {MID_FREQUENCY, M_Frequency, sizeof(M_Frequency) / sizeof(M_ITEM)},  // Menu Frequency
    {MID_BKLT, M_BkLt, sizeof(M_BkLt) / sizeof(M_ITEM)},                 // Menu Option->BKLT
    {MID_FMCE, M_FMCE, sizeof(M_FMCE) / sizeof(M_ITEM)},                 // Menu Option->FMCE
    {MID_FMMP, M_FMMP, sizeof(M_FMMP) / sizeof(M_ITEM)},                 // Menu Option->FMMP
    {MID_DEEM, M_DEEM, sizeof(M_DEEM) / sizeof(M_ITEM)},                 // Menu Option->DEEM
};

void LCDEN(void)  // Generate LCD EN pulse
{
	digitalWrite(LCD_E_PIN, HIGH);
	delayMicroseconds(1);
	digitalWrite(LCD_E_PIN, LOW);
	//delayMicroseconds(1);
}

void LCDCmd(uint8_t Cmd)  // Write LCD command
{
	digitalWrite(LCD_RS_PIN, LOW);
	PORTB = Cmd >> 4;  // High 4 bits, with LCD E pin low
	LCDEN();
	PORTB = Cmd & 0x0f;  // Low 4 bits, with LCD E pin low
	LCDEN();
	delayMicroseconds(50);
}

void LCDData(uint8_t Data)  // Write LCD data
{
	digitalWrite(LCD_RS_PIN, HIGH);
	PORTB = (Data >> 4);  // High 4 bits, with LCD E pin low
	LCDEN();
	PORTB = (Data & 0x0f);  // Low 4 bits, with LCD E pinlow
	LCDEN();
	delayMicroseconds(50);
}

void LCDClr(void)
{
	LCDCmd(0x01);  // Clear LCD
	delay(5);
}

void LCDClr1(void)
{
	LCDXYStr_P(0, 1, (PGM_P)F("                "));  // Clear LCD's 2nd row
}

void LCDOn(void)
{
	if (nBacklightKeep && bLCDOff)
	{
		analogWrite(LCD_BKLT_PIN, nBacklightAdj);  // Set LCD backlight PWM
		bLCDOff = false;
	}
	nBacklightTimer = millis();
}

void LCDInit(void)
{
	DDRB = B111111;  // D8-D13 output
	pinMode(LCD_RS_PIN, OUTPUT);
	analogWrite(LCD_BKLT_PIN, 255);  // Set LCD backlight PWM always on for booting

	LCDCmd(0x28);  // 4 bits interface
	delay(5);
	LCDCmd(0x28);
	delay(5);
	LCDCmd(0x28);
	delay(5);

	LCDCmd(0x08);  // LCD off
	delayMicroseconds(50);
	LCDClr();      // Clear LCD
	LCDCmd(0x06);  // Auto increment
	delayMicroseconds(50);
	LCDCmd(0x0c);  // LCD on
	delayMicroseconds(50);
}  // void LCDInit(void)

void LCDXY(uint8_t x, uint8_t y)  // x:0-15, y:0-1
{
	LCDCmd(0x80 + y * 0x40 + x);
}

void LCDXYChar(uint8_t x, uint8_t y, char c)  // Display char at x:0-15, y:0-1
{
	LCDXY(x, y);
	LCDData(c);
}

void LCDXYStr(uint8_t x, uint8_t y, const char *str)  // Display string at x:0-15, y:0-1
{
	const char *p;
	char c;

	LCDXY(x, y);
	p = str;
	while ((c = *p++))
		LCDData(c);
}

void LCDXYStr_P(uint8_t x, uint8_t y, PGM_P str)  // Display PROGMEM string at x:0-15, y:0-1
{
	const char *p;
	char c;

	LCDXY(x, y);
	p = str;
	while ((c = pgm_read_byte_near(p++)))
		LCDData(c);
}

void LCDFullStr_P(PGM_P str)  // Display PROGMEM string to full(2x16 chars) LCD, fill with blank if string is less than 32 chars
{
	const char *p;
	char c;
	uint8_t x, y;
	bool bInStr;

	p = str;
	bInStr = true;
	for (y = 0; y <= 1; y++) {
		for (x = 0; x <= 15; x++) {
			if (!x)
				LCDXY(0, y);

			if (bInStr) {
				c = pgm_read_byte_near(p++);
				if (!c) {
					c = ' ';
					bInStr = false;
				}
			}
			else
				c = ' ';

			LCDData(c);
		}
	}
}  // void LCDFullStr_P(PGM_P str)  // Display PROGMEM string to full(2x16 chars) LCD, fill with blank if string is less than 32 chars

   // Display string at x:0-15, y:0-1
void LCDXYStrLen(uint8_t x, uint8_t y, char *str, uint8_t nLen, bool bLeftAlign)
{
	char *p, c;
	uint8_t i, n;

	LCDXY(x, y);
	p = str;
	n = nLen - strlen(str);
	if (!bLeftAlign) {
		for (i = 0; i < n; i++)
			LCDData(' ');
	}

	while ((c = *p++))
		LCDData(c);

	if (bLeftAlign) {
		for (i = 0; i < n; i++)
			LCDData(' ');
	}
}  // void LCDXYStrLen(uint8_t x, uint8_t y, char *str, uint8_t nLen, bool bLeftAlign)

   // Display PROGMEM string at x:0-15, y:0-1
void LCDXYStrLen_P(uint8_t x, uint8_t y, PGM_P str, uint8_t nLen, bool bLeftAlign)
{
	char c;
	const char *p;
	uint8_t i, n;

	LCDXY(x, y);
	p = str;
	n = nLen - strlen_P(str);
	if (!bLeftAlign) {
		for (i = 0; i < n; i++)
			LCDData(' ');
	}

	while ((c = pgm_read_byte_near(p++)))
		LCDData(c);

	if (bLeftAlign) {
		for (i = 0; i < n; i++)
			LCDData(' ');
	}
}  // void LCDXYStrLen_P(uint8_t x, uint8_t y, PGM_P str, uint8_t nLen, bool bLeftAlign)

   // Display signed integer at x:0-15, y:0-1. Righ aligned, spaces filled at left. Too long integers are not allowed.
void LCDXYIntLen(uint8_t x, uint8_t y, int32_t n, uint8_t nLen)
{
	int8_t i;
	int32_t r;

	if (n >= 0)
		r = n;
	else
		r = -n;

	i = nLen - 1;
	do {
		LCDXYChar(x + i--, y, '0' + (r % 10));
		r = r / 10;
	} while (r);

	if (n < 0)
		LCDXYChar(x + i--, y, '-');

	while (i >= 0)
		LCDXYChar(x + i--, y, ' ');
}

// Display unsigned integer at x:0-15, y:0-1. Righ aligned, '0' filled at left. Too long unsigned integers are not allowed.
void LCDXYUIntLenZP(uint8_t x, uint8_t y, uint32_t n, uint8_t nLen)
{
	int8_t i;
	uint32_t r;
	r = n;
	i = nLen - 1;
	do {
		LCDXYChar(x + i--, y, '0' + (r % 10));
		r = r / 10;
	} while (r);

	while (i >= 0)
		LCDXYChar(x + i--, y, '0');
}

void intLRotEnc(void)
{
	if (digitalRead(SH1A_PIN) == digitalRead(SH1B_PIN))
		++nLRot;
	else
		--nLRot;
}

int8_t GetLRot(void)
{
	int8_t n;
	if (nLRot)
	{
		noInterrupts();
		n = nLRot;
		nLRot = 0;
		interrupts();
		LCDOn();
		return n;
	}
	return 0;
}

void intRRotEnc(void)
{
	if (digitalRead(SH2A_PIN) == digitalRead(SH2B_PIN))
		++nRRot;
	else
		--nRRot;
}

int8_t GetRRot(void)
{
	int8_t n;
	if (nRRot)
	{
		noInterrupts();
		n = nRRot;
		nRRot = 0;
		interrupts();
		LCDOn();
		return n;
	}
	return 0;
}

uint8_t PeekKey(void)
{
	int8_t i;
	uint16_t nADC;
	uint8_t nKey0 = 0xff, nKey;

	for (i = 0; i < 20;)
	{
		nADC = analogRead(0);
		if (nADC < (ADC_LROT + ADC_RROT) / 2)
			nKey = KEY_LROT;
		else if (nADC < (ADC_RROT + ADC_TUNE) / 2)
			nKey = KEY_RROT;
		else if (nADC < (ADC_TUNE + ADC_STEP) / 2)
			nKey = KEY_TUNE;
		else if (nADC < (ADC_STEP + ADC_BAND) / 2)
			nKey = KEY_STEP;
		else if (nADC < (ADC_BAND + ADC_FILTER) / 2)
			nKey = KEY_BAND;
		else if (nADC < (ADC_FILTER + ADC_NONE) / 2)
			nKey = KEY_FILTER;
		else
			nKey = 0;

		if (nKey == nKey0)
			++i;
		else {
			i = 0;
			nKey0 = nKey;
		}
	}
	return nKey;
}

uint8_t GetKey(void)
{
	uint8_t nKey0, nKey;
	uint32_t timer1;  // Long press timer
	static uint8_t nKeyWaitUp = 0;
	static uint32_t tKeyWaitUp;

	if (nKeyWaitUp && (millis() - tKeyWaitUp) < TIMER_LAST_LP)
		while ((nKey0 = PeekKey()) == nKeyWaitUp)
			;
	else
		nKey0 = PeekKey();

	nKeyWaitUp = 0;
	if (!nKey0)
		return 0;

	timer1 = millis();
	while ((millis() - timer1) < TIMER_LONGPRESS)
	{
		if (!(nKey = PeekKey()))
		{
			LCDOn();
			return nKey0;  // Key up
		}
		if (nKey != nKey0)
		{  // Another key pressed
			nKey0 = nKey;
			timer1 = millis();  // Reset long press timer for new key
			continue;
		}
	}
	tKeyWaitUp = millis();
	nKeyWaitUp = nKey0;
	LCDOn();
	return nKey0 | KEY_LONGPRESS;
}  // uint8_t GetKey(void)

void TestRotKey(void)  // Show Rotary encoder and key data on LCD
{
	uint8_t uLRot = 0;
	int8_t iRRot = 0, i, iTmp;
	LCDClr();
	LCDXYStr_P(6, 0, (PGM_P)F("TEST"));
	nLRot = 0;
	nRRot = 0;

	for (i = 0; ; i++)
	{
		iTmp = GetLRot();
		if (iTmp && PeekKey() == KEY_RROT)
		{  // Right rotary encoder pressed while rotate left rotary encoder
			if (iTmp < 0)
			{                   // Left encoder: CCW
				if (uLRot == 67 && iRRot == 77)
					NVMInit();               // Reinitialize NV memory
			}
			return;
		}
		uLRot += iTmp;
		LCDXYIntLen(0, 0, uLRot, 4);

		iRRot += GetRRot();
		LCDXYIntLen(12, 0, iRRot, 4);

		if (!(i % 25))
			LCDXYIntLen(6, 1, analogRead(0), 4);
	}
}

void LCDUpdate(void)
{
	int8_t i8;
	uint16_t bw;
	// Update band: LW/MW/SW/FM
	LCDXYStr(BAND_X, BAND_Y, (char *)pszBands[nBand]);

	// Update step: 1K/5K/9K/10K/25K/45K/50K/90K/100/500
	if (nBandStep[nBand][nStepIdx] < 100)
		i8 = 1;
	else
		i8 = 0;
	LCDXYIntLen(STEP_X, STEP_Y, nBandStep[nBand][nStepIdx], 3 - i8);
	if (i8)
		LCDXYChar(STEP_X + 2, STEP_Y, 'K');
	Serial.println(F("LCDUpdate:"));
	// Update IF filter bandwidth
	if (nRFMode == RFMODE_FM)
	{
		bw = M_FMFilter[nFMFilter];
	}
	else
	{
		bw = M_AMFilter[nAMFilter];
	}	
	if (bw == 0 && nRFMode == RFMODE_FM)
		LCDXYStr(FILTER_X, FILTER_Y, "AUTO");
	else
	{
		LCDXYIntLen(FILTER_X, FILTER_Y, bw, 3);
		LCDXYChar(FILTER_X + 3, FILTER_Y, 'K');
	}
}

void CheckUpdateSig(void)
{
	char c;
	float fv;
	GetRFStatReg();
	// FM stereo indicator. 'S' for FM stereo, ' ' for FM mono or AM mode,  'M' for FM forced mono
	c = ' ';  // AM mode or FM mono
	if (nRFMode == RFMODE_FM)
	{
		if (bSTIN)
			c = 'S';  // Stereo
	}
	if (nDelayedSmooth--)
	{
		nRSSI_Disp = nRSSI;
		nSNR_Disp = nSNR;
	}
	else
	{
		fv = (float)nRSSI_Last * 0.7 + (float)nRSSI * 0.3;
		if (fv > 0.0)
			nRSSI_Disp = int(fv + 0.5);
		else
			nRSSI_Disp = int(fv - 0.5);

		fv = (float)nSNR_Last * 0.7 + (float)nSNR * 0.3;
		if (fv > 0.0)
			nSNR_Disp = int(fv + 0.5);
		else
			nSNR_Disp = int(fv - 0.5);
	}

	LCDXYIntLen(RSSI_X, RSSI_Y, constrain(nRSSI_Disp, -20, 120), 3);// Update RF signal level in dBuv
	LCDXYChar(STEREO_X, STEREO_Y, c);                               // Update FM stereo indicator
	LCDXYIntLen(SN_X, SN_Y, constrain(nSNR_Disp, -99, 127), 3);     // Update S/N ratio in dB

	nRSSI_Last = nRSSI_Disp;
	nSNR_Last = nSNR_Disp;
	if (nDelayedSmooth < 0)
		nDelayedSmooth = 0;
}

void ShowMisc(void)
{
	char s[] = "3e- A";
	const char ds[] = "-57";
	const char cmode[] = "FAXX";

	s[0] = '0' + 0;  // AGC threshold, 0 for lowest, 3 for highest

	if (nRFMode == RFMODE_FM)
	{
		if (1)
			s[1] = 'E';             // FM channel equalizer on
		s[2] = ds[1];     // Deemphasis, '-' for none, '5' for 50us, '7' for 75us
		s[3] = '0' + 0;  // FM dynamic bandwidth, 0 to 3 = narrow bandwidth to wide bandwidth
	}

	// Update mode: F/A/X, F=FM, A=AM, X=AUX
	s[4] = cmode[(0 << 1) + nRFMode];
	LCDXYStr(ALT_X, ALT_Y, s);
}

void ShowVol(void)
{
	LCDXYStr_P(ALT_X, ALT_Y, (PGM_P)F("VOL"));
	LCDXYIntLen(ALT_X + 3, ALT_Y, nVolume, 2);  // Volume
}

void CheckUpdateAlt(int8_t nShow)  // Check and update ALT area
{
	static int8_t nShowLast = ALT_MISC;
	static uint32_t nTimerAlt = 0;

	if (nShow != ALT_AUTO)
	{
		nTimerAlt = millis();
		nShowLast = nShow;
	}

	if ((millis() - nTimerAlt) < TIMER_ALTDISP)
	{  // Not timeout
		switch (nShowLast)
		{
		case ALT_MISC:
			ShowMisc();
			break;

		case ALT_VOL:
			ShowVol();
			break;
		}
	}
	else
	{  // Timeout, swap beteen ALT_MISC/ALT_TIME
		nShowLast = ALT_MISC;
		ShowMisc();
		nTimerAlt = millis();
	}
}  // void CheckUpdateAlt(int8_t nShow)  // Check and update ALT area

void sprhex2(char *str, uint8_t v)
{
	uint8_t n;

	n = v >> 4;
	*str = ((n < 10) ? '0' : ('A' - 10)) + n;
	n = v & 0x0f;
	*(str + 1) = ((n < 10) ? '0' : ('A' - 10)) + n;
}

void Menu_BacklightAdj(void)
{
	int16_t i16 = nBacklightAdj;
	uint8_t nKey, lp;
	// 0123456789012345
	LCDXYStr_P(0, 1, (PGM_P)F("BACKLT ADJ:     "));
	for (lp = 0; ; lp++)
	{
		i16 = (i16 + GetLRot() + GetRRot() + 256) % 256;
		LCDXYIntLen(12, 1, i16, 3);
		analogWrite(LCD_BKLT_PIN, i16);

		if ((nKey = GetKey()))
		{
			nBacklightAdj = (uint8_t)i16;
			LCDClr1();
			if (!(nKey & (KEY_LROT | KEY_RROT)))
				bExitMenu = true;
			NV_write_byte((uint8_t *)NVMADDR_BKADJ, nBacklightAdj);
			return;
		}
		if (!(lp % 16))
			CheckUpdateSig();
		delay(64);
	}
}  // void Menu_BacklightAdj(void)

void Menu_BacklightKeep(void)
{
	int16_t i16 = nBacklightKeep;
	uint8_t nKey, lp;

	// 0123456789012345
	LCDXYStr_P(0, 1, (PGM_P)F("BACKLT KEEP:    "));
	for (lp = 0; ; lp++)
	{
		i16 = (i16 + GetLRot() + GetRRot() + 256) % 256;
		LCDXYIntLen(13, 1, i16, 3);

		if ((nKey = GetKey()))
		{
			nBacklightKeep = (uint8_t)i16;
			LCDClr1();
			if (!(nKey & (KEY_LROT | KEY_RROT)))
				bExitMenu = true;
			NV_write_byte((uint8_t *)NVMADDR_BKKEEP, nBacklightKeep);
			return;
		}
		if (!(lp % 16))
			CheckUpdateSig();
		delay(64);
	}
}  // void Menu_BacklightKeep(void)

void Menu_Stat(void)
{
	uint8_t nKey, u8, lp = 0;
	int8_t i8, nItem = 0, nItemOld = -1, nItems;
	PGM_P p;
	char s[10];
	// 0123456789012345
	PGM_P str[] = { (PGM_P)F("FM US NOISE:"),    // 1st item
		(PGM_P)F("FM MULTIPATH:"),
		(PGM_P)F("RF OFFSET:     K"),
		(PGM_P)F("IF FILTER:"),
		(PGM_P)F("MODULATION:    %"),
	};
	nItems = sizeof(str) / sizeof(PGM_P);
	for (;;)
	{
		if ((nKey = GetKey()))
		{
			if (!(nKey & (KEY_LROT | KEY_RROT)))
				bExitMenu = true;
			LCDClr1();
			return;
		}
		if ((i8 = GetLRot() + GetRRot()))
			nItem = (nItems + nItem + i8) % nItems;
		if (nItem != nItemOld)
		{
			LCDClr1();
			if (nItem == 0 && nRFMode == RFMODE_AM)
				LCDXYStr_P(0, 1, (PGM_P)F("AM HF NOISE:"));
			else if(nItem == 1 && nRFMode == RFMODE_AM)
				LCDXYStr_P(0, 1, (PGM_P)F("AM COCHANNEL:"));
			else
				LCDXYStr_P(0, 1, str[nItem]);
			nItemOld = nItem;
			lp = 0;
		}
		else if (++lp % 16)
		{
			delay(64);
			continue;
		}

		CheckUpdateSig();
		int16_t sQuality[7] = { 0 };
		Get_Cmd(32 + nRFMode, 128, sQuality, 7);
		switch (nItem)
		{
		case 0:
			LCDXYIntLen(13, 1, sQuality[2] / 10, 3);  // FM ultrasonic noise detector & AM high frequency noise detector
			break;

		case 1:
			LCDXYIntLen(13, 1, sQuality[3] / 10, 3);  // FM multipath & AM co-channel detector
			break;

		case 2:
			LCDXYIntLen(11, 1, sQuality[4] / 10, 4);// Frequency offset
			break;

		case 3:
			u8 = sQuality[5] / 10;  // IF filter bandwidth
			LCDXYIntLen(12, 1, u8, 3);
			LCDXYChar(15, 1, 'K');
			break;

		case 4:
			LCDXYIntLen(12, 1, sQuality[6] / 10, 3);  // Modulation index
			break;
		}
	}
}  // void Menu_Stat(void)

bool YesNo(bool bChkSig)
{
	uint8_t u8, lp;

	LCDXYStr_P(13, 1, (PGM_P)F("Y/N"));
	GetKey();  // Clear key
	for (lp = 0; ; lp++) {
		if ((u8 = GetKey())) {
			if (u8 == KEY_LROT)
				return true;
			else if (u8 == KEY_RROT)
				return false;
		}

		if (bChkSig && !(lp % 16))
			CheckUpdateSig();
		delay(64);
	}
}

void Menu_Sleep(void)
{
	cli();                                // Disable interrupt
	analogWrite(LCD_BKLT_PIN, 0);         // Set LCD backlight off
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);  // Power down mode, external oscillator is stopped
	sleep_mode();                         // Sleep here
}

void ProcSubMenu(struct M_SUBMENU *pSubMenu)
{
	int8_t i8;
	uint8_t u8, lp, nHit;
	int8_t nFirst = 0;
	for (;;)
	{
		// Show max 3 sub menu items
		LCDClr1();
		for (i8 = 0; i8 < ((pSubMenu->nItemCount < 3) ? pSubMenu->nItemCount : 3); i8++)
			LCDXYStrLen_P(1 + i8 * 5, 1, (pSubMenu->pMItem + ((nFirst + i8) % pSubMenu->nItemCount))->pszMTxt, 4, true);

		// Display special indicator char for selected item
		switch (pSubMenu->nMID)
		{
		case MID_FMCE:
			nHit = nFMCEQ;
			break;

		case MID_FMMP:
			nHit = nFMEMS;
			break;

		case MID_DEEM:
			nHit = nDeemphasis;
			break;

		default:
			nHit = MID_NONE;  // Magic number, no item selected
			break;
		}

		if (nHit != MID_NONE) {
			nHit = (nHit - nFirst + pSubMenu->nItemCount) % pSubMenu->nItemCount;
			if (nHit <= 2)
				LCDXYChar(nHit * 5, 1, CHAR_SEL);
		}
		for (lp = 0; ; lp++)
		{
			// Process key
			if ((i8 = GetKey()))
			{
				if (i8 & (KEY_LROT | KEY_RROT))
				{  // Item selected
					u8 = (pSubMenu->pMItem + ((nFirst + 1) % pSubMenu->nItemCount))->nMID;
					if (u8 == MID_RET)
						return;
					ProcMenuItem(u8);
					if ((pSubMenu->nMID >= MID_MIN_AUTORET) || bExitMenu)
						return;  // Auto return sub menu, or none left/right key pressed in sub menu
					else
						break;   // Redraw sub menu items
				}
				else
				{
					bExitMenu = true;  // None left/right key pressed, exit
					return;
				}
			}

			// Process rotary encoder, adjust nFirst
			if ((i8 = (GetLRot() + GetRRot())))
			{
				nFirst = (nFirst + i8 + pSubMenu->nItemCount) % pSubMenu->nItemCount;
				break;
			}

			// Update sig
			if (!(lp % 16))
				CheckUpdateSig();
			delay(64);
		}
	}
}  // void ProcSubMenu(struct M_SUBMENU *pSubMenu)


void ProcMenuItem(uint8_t nMenuID)
{
	if (bExitMenu)
		return;

	// Sub menu items
	if (nMenuID <= MID_MAX_SUB) 
	{
		ProcSubMenu(&SM_List[nMenuID]);
		return;
	}

	// Leaf menu items(w/o sub menu)
	if ((nMenuID >= MID_FMCEOFF) && (nMenuID <= MID_FMCEON))
	{
		nFMCEQ = nMenuID - MID_FMCEOFF;  // FM channel equalizer, 0=off, 1=on
		SetRFCtrlReg();
		AddSyncBits(NEEDSYNC_MISC2);
		return;
	}

	if ((nMenuID >= MID_FMMPOFF) && (nMenuID <= MID_FMMPON))
	{
		nFMEMS = nMenuID - MID_FMMPOFF;  // FM enhanced multipath suppression, 0=off, 1=on
		SetRFCtrlReg();
		AddSyncBits(NEEDSYNC_MISC2);
		return;
	}

	if ((nMenuID >= MID_DEEM0) && (nMenuID <= MID_DEEM75))
	{
		nDeemphasis = DEEMPHOFF + (nMenuID - MID_DEEM0);  // FM de-emphasis, 0=off, 1=50us, 2=75us
		SetRFCtrlReg();
		AddSyncBits(NEEDSYNC_MISC1);
		return;
	}
	
	// Misc leaf menu items(w/o sub menu)
	switch (nMenuID)
	{
	case MID_EXIT:
		bExitMenu = true;

	case MID_RET:
		return;

	case MID_BKKEEP:
		Menu_BacklightKeep();
		break;

	case MID_BKADJ:
		Menu_BacklightAdj();
		break;

	default:
		switch (nMenuID)
		{  // Use another switch to avoid R_AVR_7_PCREL error

		case MID_STAT:
			Menu_Stat();  // Show status
			break;

		case MID_SLP:  // Sleep MCU
			Menu_Sleep();  // Should never return
			break;

		}
		break;
	}
}// void ProcMenuItem(uint8_t nMenuID)


void Menu(uint8_t nMenuID)
{
	bExitMenu = false;
	ProcMenuItem(nMenuID);
	LCDClr1();
	LCDUpdate();
}
