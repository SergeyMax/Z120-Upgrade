#include "global.h"

#define NVMSIG0     'E'
#define NVMSIG1     'F'
#define NVMSIG2     0x13
#define NVMSIG3     0xF2
#define NVMSIG      ((uint32_t)NVMSIG0 + ((uint32_t)NVMSIG1 << 8) + ((uint32_t)NVMSIG2 << 16) + ((uint32_t)NVMSIG3 << 24))

// NV memory addr
#define NVMADDR_SIG          0
#define NVMADDR_BANDFREQ     4
#define NVMADDR_BAND        12
#define NVMADDR_VOL         13
#define NVMADDR_RFMODE      14
#define NVMADDR_STEPIDX     15
#define NVMADDR_FMFILTER    16
#define NVMADDR_AMFILTER    17
#define NVMADDR_BKADJ       18
#define NVMADDR_BKKEEP      19
#define NVMADDR_MISC1       20
#define NVMADDR_MISC2       21
#define NVMADDR_MISC3       22

// NV memory initialization data
const uint8_t NVM_INIT[] PGM =
{
	4, NVMSIG0, NVMSIG1, NVMSIG2, NVMSIG3,
	0x80 + 8,  0xff,   // Band frequency
	8, 3, 12, 0, 0, 0, 0, 255, 0, // Band, Vol, RFMode, StepIdx, FMFilter, AMFilter,BkAdj, BkKeep
	3, B01001011,B11100010, 0,  // Misc1 Misc2, Misc3
	0  // End
};


void NVMInit(void);
void NVMGetArgs(void);
void NVMUnpkWrData(const uint8_t* pPGMAddr, uint8_t *pNVMAddr);

#if DEBUG
uint8_t NV_read_byte(uint8_t *p);
uint16_t NV_read_word(uint16_t *p);
void NV_write_byte(uint8_t *p, uint8_t val);
void NV_write_word(uint16_t *p, uint16_t val);
#else
#define NV_read_byte(p)         eeprom_read_byte((p))
#define NV_read_word(p)         eeprom_read_word((p))
#define NV_write_byte(p, val)   eeprom_write_byte((p), (val))
#define  NV_write_word(p, val)  eeprom_write_word((p), (val))
#endif
