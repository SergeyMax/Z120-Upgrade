#include "global.h"

// The following 7 values are individual for each device
// Calculated values

/*
// eggplant886's values
#define ADC_LROT    11
#define ADC_RROT    112
#define ADC_TUNE    195
#define ADC_STEP    314
#define ADC_BAND    533
#define ADC_FILTER  745
#define ADC_NONE    1023*/

// ace919's values
#define ADC_LROT    12
#define ADC_RROT    172
#define ADC_TUNE    344
#define ADC_STEP    503
#define ADC_BAND    657
#define ADC_FILTER  811
#define ADC_NONE    996

#define KEY_LROT        0x01
#define KEY_RROT        0x02
#define KEY_TUNE        0x04
#define KEY_STEP        0x08
#define KEY_BAND        0x10
#define KEY_FILTER      0x20
#define KEY_LONGPRESS   0x80

#define TIMER_LONGPRESS    1200  // Key long press time, ms
#define TIMER_LAST_LP       400  // Is last long press key? ms

// Char display on LCD for selected item
#define CHAR_SEL    0x7e  // Right arrow

// LCD locations
#define BAND_X      0
#define BAND_Y      0

#define FREQ_X      2
#define FREQ_Y      0

#define RSSI_X      9
#define RSSI_Y      0

#define STEREO_X   12
#define STEREO_Y    0

#define SN_X       13
#define SN_Y        0

#define FILTER_X    6
#define FILTER_Y    1

#define STEP_X      2
#define STEP_Y      1

#define ALT_X      11
#define ALT_Y       1

// Display contents in ALT area
#define ALT_AUTO    0
#define ALT_MISC    1
#define ALT_VOL     2

// Menu IDs with sub menus, not auto return
#define MID_OPTION      0x00
#define MID_FREQUENCY   0x01
#define MID_BKLT        0x02

// Menu IDs with sub menus, auto return
#define MID_MIN_AUTORET 0x03  // Min ID number with auto return property
#define MID_FMCE        0x03  // FM channel equalizer
#define MID_FMMP        0x04  // FM enhanced multipath suppression
#define MID_DEEM        0x05  // FM de-emphasis
#define MID_MAX_SUB     0x05  // Max ID number with sub menus

// Menu IDs of leaves
#define MID_FMCEOFF     0x25
#define MID_FMCEON      0x26
#define MID_FMMPOFF     0x27
#define MID_FMMPON      0x28
#define MID_DEEM0       0x29
#define MID_DEEM50      0x2a
#define MID_DEEM75      0x2b
#define MID_BKKEEP      0x2c
#define MID_BKADJ       0x3d

#define MID_STAT        0x42
#define MID_SLP         0x43

// Special menu IDs
#define MID_RET         0xfe
#define MID_EXIT        0xff
#define MID_NONE        0xf0  // Magic number, no item selected


// Menu item structure
struct M_ITEM
{
	uint8_t nMID;
	const char *pszMTxt;
};

// Sub menu structure
struct M_SUBMENU
{
	uint8_t nMID;
	struct M_ITEM *pMItem;
	uint8_t nItemCount;
};

void LCDEN(void);
void LCDCmd(uint8_t Cmd);
void LCDData(uint8_t Data);
void LCDClr(void);
void LCDClr1(void);
void LCDOn(void);
void LCDInit(void);
void LCDXY(uint8_t x, uint8_t y);
void LCDXYChar(uint8_t x, uint8_t y, char c);
void LCDXYStr(uint8_t x, uint8_t y, const char *str);
void LCDXYStr_P(uint8_t x, uint8_t y, PGM_P str);
void LCDFullStr_P(PGM_P str);
void LCDXYStrLen(uint8_t x, uint8_t y, char *str, uint8_t nLen, bool bLeftAlign);
void LCDXYStrLen_P(uint8_t x, uint8_t y, PGM_P str, uint8_t nLen, bool bLeftAlign);
void LCDXYIntLen(uint8_t x, uint8_t y, int32_t n, uint8_t nLen);
void LCDXYUIntLenZP(uint8_t x, uint8_t y, uint32_t n, uint8_t nLen);

void intLRotEnc(void);
int8_t GetLRot(void);
void intRRotEnc(void);
int8_t GetRRot(void);
uint8_t PeekKey(void);
uint8_t GetKey(void);
void TestRotKey(void);

void LCDUpdate(void);
void CheckUpdateSig(void);
void ShowMisc(void);
void ShowVol(void);
void CheckUpdateAlt(int8_t nShow);

void sprhex2(char *str, uint8_t v);
void Menu_BacklightAdj(void);
void Menu_BacklightKeep(void);
void Menu_Stat(void);
bool YesNo(bool bChkSig);
void Menu_Sleep(void);

void ProcSubMenu(struct M_SUBMENU *pSubMenu);
void ProcMenuItem(uint8_t nMenuID);
void Menu(uint8_t nMenuID);